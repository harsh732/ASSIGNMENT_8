﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment8_Group2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        VM vm = new VM();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnShowResults_Click(object sender, RoutedEventArgs e)
        {
            int total = 20,CorrectAnswered,InCorrectAnswered;

            InCorrectAnswered =vm.ShowResults();
            CorrectAnswered = total - InCorrectAnswered;
            if (CorrectAnswered >= 15)
            {
                MessageBox.Show("You are Passed!!");
            }
            else
            {
                MessageBox.Show("You are Failed!!");
            }
          
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        
            vm = new VM();
            DataContext = vm;
    }
    }
}
