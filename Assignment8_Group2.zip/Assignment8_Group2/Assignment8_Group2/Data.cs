﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8_Group2
{
    class Data
    {
        public string InCorrectAnsQues { get; set; }

        public override string ToString()
        {
            return  InCorrectAnsQues;
        }
    }

/*    class DataSortByCode : IComparer<Data>
    {
        public int Compare(Data x, Data y)
        {
            int result = 0;

            if (x.Code > y.Code)
                result = 1;
            else if (x.Code < y.Code)
                result = -1;

            return result;
        }
    }
    class DataSortByValue : IComparer<Data>
    {
        public int Compare(Data x, Data y)
        {
            return x.Value - y.Value;
        }
    } */
}
