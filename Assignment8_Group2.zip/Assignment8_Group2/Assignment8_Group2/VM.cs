﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8_Group2
{
    class VM : INotifyPropertyChanged
    {
        string[] correctAnswers = new string[] { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
        const int TOTAL_QUESTIONS = 20;
        private List<Data> ld;
        int count = 0;

        string _correctAnswers,_incorrectAnswers;

        private ObservableCollection<Data> ocd;
        public ObservableCollection<Data> OCD
        {
            get { return ocd; }
            set { ocd = value; OnPropertyChanged(); }
        }

        public string CorrectAnswers
        {
            get { return _correctAnswers; }
            set { _correctAnswers = value;OnPropertyChanged(); }
        }

        public string InCorrectAnswers
        {
            get { return _incorrectAnswers; }
            set { _incorrectAnswers = value; OnPropertyChanged(); }
        }

        public VM()
        {
           
        }

        public int ShowResults() {

            const string DATA_FILE = "data.txt";

            string[] allLines = File.ReadAllLines(DATA_FILE);
            string allText = File.ReadAllText(DATA_FILE);
            List<string> lines = File.ReadLines(DATA_FILE).ToList();

            string[] splitText = allText.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            ld = new List<Data>();
            int j = 0;

            foreach (string st in splitText)
            {
                Data d = new Data();
                string[] sts = st.Split(new char[] { ',' });
                for (int i = 0; i < sts.Length; i++)
                {
                    sts[i] = sts[i].Trim();

                    if (sts[i] != correctAnswers[j])
                    {
                        d.InCorrectAnsQues = "Incorrect Answered Question is: " + " " + (j + 1).ToString();
                        ld.Add(d);
                        count++;
                    }
                }
                j++;
            }

            lines.Sort();
            ocd = new ObservableCollection<Data>(ld);
            OCD = ocd;

            _incorrectAnswers = count.ToString();
            InCorrectAnswers = _incorrectAnswers;
            _correctAnswers = (TOTAL_QUESTIONS - count).ToString();
            CorrectAnswers = _correctAnswers;
            return count;

        }

        public void Sort()
        {
            //switch (sb)
            //{
            //    case SortBy.CODE:
            //        ld.Sort(new DataSortByCode());
            //        sb = SortBy.VALUE;
            //        break;
            //    case SortBy.VALUE:
            //        ld.Sort(new DataSortByValue());
            //        sb = SortBy.CODE;
            //        break;
            //}
            //OCD = new ObservableCollection<Data>(ld);
            //ld.B
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler eventHandler = this.PropertyChanged;
            if (eventHandler != null)
            {
                eventHandler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
